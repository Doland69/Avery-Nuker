# Avery Nuker
Fastest Python Discord Server Nuker

## Installation And Use
- Open the [Releases](https://github.com/skeqt/AveryNuker/releases) Page.
- Click on the latest version.
- Click on the `AveryNuker.zip`.
- Extract the zip.
- Open `avery.exe`.
- Enter your user token or bot token.

## Support
For help and support you can add my discord: `skeet#7000`
Also if you skid this give me credits

## Warning
All of these tools are used by your own risk, i do not take responsiblity for any of your actions.
